# EasyPlayer

> 集 flv.js, rtmp, hls, websocket 于一身的`网页直播/点播`播放器, 使用简单, 功能强大, 下面这张图在一个网页上演示了 rtmp流, hls流, websocket流 等的播放效果

![](http://ww1.sinaimg.cn/large/79414a05gy1fmpjkmmm57j20cz0lutjj.jpg)

## HTML 集成示例

```html
<!DOCTYPE HTML>
<html>
    <head>
        <title>easy-player</title>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no" name="viewport">
    <body>
        <easy-player video-url="rtmp://live.hkstv.hk.lxdns.com/live/hks" live="true"></easy-player>
        <easy-player video-url="http://live.hkstv.hk.lxdns.com/live/hks/playlist.m3u8" live="false"></easy-player>
        <easy-player video-url="ws://121.40.210.97:3000/play?stream=rtsp://username:password@221.226.23.58:5504/Streaming/Channels/102"></easy-player>
    <script type="text/javascript" src="easy-player-element.min.js"></script></body>
</html>
```

## 配置属性

- `video-url` 视频流地址 String default ''
- `video-title` 视频右上角显示的标题 String default ''
- `snap-url` 视频封面图片 String default ''
- `auto-play` 自动播放 Boolean default true
- `live` 是否直播, 标识要不要显示进度条 Boolean default false
- `alt` 视频流地址没有指定情况下, 视频所在区域显示的文字, 相当于 html img 标签的 alt 属性 String default '无信号'
- `muted` 是否静音 Boolean default false
- `aspect` 视频显示区域的宽高比 String default '16:9'
- `isaspect` 视频显示区域是否强制宽高比 Boolean default true
- `loading` 指示加载状态, 支持 sync 修饰符
- `fluent` 流畅模式, Boolean default true
- `timeout` 加载超时(秒) Number default 20
- `stretch` 是否不同分辨率强制铺满窗口，默认为false
- `show-custom-button` 是否在工具栏显示自定义按钮(极速/流畅, 拉伸/标准), Boolean default true
- `isresolution` 是否在播放m3u8时显示多清晰度选择，默认为false
- `resolution` 供选择的清晰度  "yh,fhd,hd,sd", yh:原始分辨率，fhd:超清，hd:高清，sd:标清
- `resolutiondefault` 默认播放的清晰度 "hd"

### HTTP-FLV播放相关属性

- `hasaudio` 是否有音频，传递该属性可以加快启播速度 Boolean，默认不配置自动判断
- `hasvideo` 是否有视频，传递该属性可以加快启播速度 Boolean，默认不配置自动判断

## 事件回调

- `message` 触发通知消息, 参数: { type: '', message: ''}
- `ended` 播放结束, 参数: 无
- `timeupdate` 进度更新, 参数: 当前时间进度
- `pause` 暂停, 参数: 当前时间进度
- `play` 播放, 参数: 当前时间进度

## 安装使用

- 安装

`npm install @easydarwin/easyplayer --save`

copy dist/component/*.swf 到 www 根目录

- 在 Vue 中使用

copy dist/component/easy-player-lib.min.js 到 www 根目录

在 html 中引用 dist/component/easy-player-lib.min.js

``` vue
......

import EasyPlayer from '@easydarwin/easyplayer

......
  components: {
    EasyPlayer
  }
......

<EasyPlayer :videoUrl="videoUrl" :aspect="aspect" live 
    @message="$message" :fluent="fluent" :autoplay="autoplay"></EasyPlayer>

```

- 脱离 Vue 使用

copy dist/element/easy-player-element.min.js 到 www 根目录 

在 html 中引用 dist/element/easy-player-element.min.js

参考上面 **HTML 集成示例**
